extends Area2D

var posicao_original_x: float
var tween_atual: Tween

func _ready():
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
	var camera = get_viewport().get_camera_2d()
	
	if camera:
		posicao_original_x = camera.position.x

func _on_mouse_entered():
	var camera = get_viewport().get_camera_2d()
	
	if tween_atual and tween_atual.is_valid():
		tween_atual.kill()

	tween_atual = create_tween()
	tween_atual.tween_property(camera, "position:x", posicao_original_x + 300, 0.5)

func _on_mouse_exited():
	var camera = get_viewport().get_camera_2d()
	if camera:
		if tween_atual and tween_atual.is_valid():
			tween_atual.kill()

		tween_atual = create_tween()
		tween_atual.tween_property(camera, "position:x", posicao_original_x, 0.5)
