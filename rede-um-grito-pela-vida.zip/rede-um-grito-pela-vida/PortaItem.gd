extends Area2D

var aberta := false

func _ready():
	input_pickable = true

func abrir():
	if aberta:
		return

	aberta = true
	print("Porta aberta!")

	if has_node("PortaF"):
		$PortaF.visible = false

	if has_node("PortaA"):
		$PortaA.visible = true

	if has_node("CollisionShape2D"):
		$CollisionShape2D.set_deferred("disabled", true)
