extends Area2D


func _ready():
	input_pickable = true


func _on_input_event(viewport, event, shape_idx):

	if event is InputEventMouseButton:

		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:

			print("CLIQUEI NA CHAVE!")

			var inventario = get_tree().get_first_node_in_group("inventario")

			if inventario:
				print("INVENTÁRIO ENCONTRADO!")
				inventario.add_item("Chave")
			else:
				print("ERRO: INVENTÁRIO NÃO ENCONTRADO!")

			var caixa = get_tree().get_first_node_in_group("caixa_texto")

			if caixa:
				caixa.mostrar_falas([
					"Você encontrou uma chave!",
					"Ela parece ser bem antiga.",
					"Talvez ela abra alguma coisa..."
				])

			queue_free()
