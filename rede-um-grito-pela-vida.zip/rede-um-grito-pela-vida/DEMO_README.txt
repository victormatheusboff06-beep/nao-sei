DEMO COMBINADA

Base visual/movimentação:
- quarto.tscn / sala.tscn
- CamEsquerda.gd
- CamDireita.gd
- assets de portas e salas

Mecânicas adicionadas:
- Inventário com 5 slots
- OpenMenu / Close
- imagem, nome e descrição do item
- setas
- mensagem de inventário vazio
- chave clicável
- diálogo ao pegar a chave
- temporizador de 30 segundos
- porta exige a chave na DEMO
- porta troca para sala depois de aberta

Os scripts originais foram mantidos em /mecanicas.
Os scripts CamEsquerda.gd, CamDireita.gd e Porta.gd originais também foram mantidos.
A DEMO usa scripts novos apenas para fazer a integração, sem substituir os originais.
