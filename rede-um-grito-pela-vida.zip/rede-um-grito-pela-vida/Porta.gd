extends Area2D

@export_file("*.tscn") var trocaCena: String
var trocaSala = false

func _ready():
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)

func _on_mouse_entered():
	$PortaF.visible = false
	$PortaA.visible = true
	trocaSala = true

func _on_mouse_exited():
	$PortaF.visible = true
	$PortaA.visible = false
	trocaSala = false

func _process(delta):
	if Input.is_action_just_pressed("clickE") and trocaSala == true:
		_troca_cena()

func _troca_cena():
	if trocaCena:
		get_tree().change_scene_to_file(trocaCena)
