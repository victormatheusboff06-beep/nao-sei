extends Area2D


func _ready():
	input_pickable = true


func _input_event(viewport, event, shape_idx):

	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:

			var caixa = get_tree().get_first_node_in_group("caixa_texto")

			if caixa:
				caixa.mostrar_falas([
				"Sou Lucas Gabriel",
	 			"Você viu minha garrafa ?",
				"Um cara chamado Guilherme a pegou e escondeu"
				])
