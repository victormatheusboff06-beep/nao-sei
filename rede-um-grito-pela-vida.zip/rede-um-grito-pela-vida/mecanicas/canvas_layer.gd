extends CanvasLayer

var items: Array[String] = []
var selected_slot := 0

var tempo := 30.0
var puzzle_ativo := true

@onready var slots = $InventoryBar/HBoxContainer.get_children()


func _ready():
	add_to_group("inventario")

	for slot in slots:
		slot.custom_minimum_size = Vector2(80, 80)

	update_inventory()

	$Timer.text = "00:30"
	
	$OpenMenu.pressed.connect(abrir_inventario)


func add_item(item: String):
	if items.size() >= slots.size():
		print("Inventário cheio!")
		return

	items.append(item)
	print("Item adicionado: ", item)

	update_inventory()


func remove_item(item: String):
	if item in items:
		items.erase(item)
		print("Item removido: ", item)

		update_inventory()


func update_inventory():
	for i in range(slots.size()):
		if i < items.size():
			slots[i].text = items[i]
		else:
			slots[i].text = ""


func atualizar_tempo():
	var segundos = int(tempo)

	var minutos = segundos / 60
	var segundos_restantes = segundos % 60

	$Timer.text = "%02d:%02d" % [minutos, segundos_restantes]


func _process(delta):

	if puzzle_ativo:

		tempo -= delta

		if tempo <= 0:
			tempo = 0
			puzzle_ativo = false

			$Timer.text = "00:00"

			print("Tempo esgotado!")

			get_tree().quit()

		else:
			atualizar_tempo()


func _on_button_pressed():
	selected_slot = 0
	print("Slot 1 selecionado")


func _on_button_2_pressed():
	selected_slot = 1
	print("Slot 2 selecionado")


func _on_button_3_pressed():
	selected_slot = 2
	print("Slot 3 selecionado")


func _on_button_4_pressed():
	selected_slot = 3
	print("Slot 4 selecionado")


func _on_button_5_pressed():
	selected_slot = 4
	print("Slot 5 selecionado")
	
	
func abrir_inventario():
	$InventoryMenu.abrir_inventario()
