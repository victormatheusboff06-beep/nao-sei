extends Button


func _get_drag_data(at_position):

	if text == "":
		return null

	var preview = Label.new()
	preview.text = text
	preview.add_theme_font_size_override("font_size", 30)

	set_drag_preview(preview)

	return text
