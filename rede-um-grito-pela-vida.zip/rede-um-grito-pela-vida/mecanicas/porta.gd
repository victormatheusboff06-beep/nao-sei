extends Area2D

var aberta := false


func _ready():
	input_pickable = true


func _input_event(viewport, event, shape_idx):

	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			print("Cliquei na porta!")


func abrir():

	if aberta:
		return

	aberta = true

	print("Porta aberta!")

	$portafechada.visible = false
	$portaaberta.visible = true

	$CollisionShape2D.set_deferred("disabled", true)

	
	get_tree().quit()
