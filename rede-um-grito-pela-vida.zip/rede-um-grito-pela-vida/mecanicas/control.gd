extends Control


func _can_drop_data(at_position, data):
	return data == "Chave"


func _drop_data(at_position, data):
	if data == "Chave":
		print("Chave colocada na porta!")

		var porta = get_parent()
		porta.abrir()

		var inventario = get_tree().get_first_node_in_group("inventario")

		if inventario:
			inventario.remove_item("Chave")
