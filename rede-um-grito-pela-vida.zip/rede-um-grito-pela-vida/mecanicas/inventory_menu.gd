extends Panel

@onready var item_image = $ItemImage
@onready var item_name = $ItemName
@onready var item_description = $ItemInformation
@onready var close_button = $Close

var item_atual := 0
var itens = []


func _ready():
	visible = false

	close_button.pressed.connect(fechar_inventario)

	atualizar_item()


func abrir_inventario():
	visible = true
	atualizar_item()


func fechar_inventario():
	visible = false


func atualizar_item():

	var inventario = get_tree().get_first_node_in_group("inventario")

	if not inventario:
		return

	itens = inventario.items

	if itens.is_empty():
		item_image.texture = null
		item_name.text = "Inventário vazio"
		item_description.text = "Você não possui nenhum item."
		return

	if item_atual >= itens.size():
		item_atual = itens.size() - 1

	var item = itens[item_atual]

	if item == "Chave":
		item_name.text = "Chave"
		item_description.text = "Uma chave antiga. Talvez ela abra alguma porta."
		item_image.texture = preload("images.png")


func _on_left_arrow_pressed():

	var inventario = get_tree().get_first_node_in_group("inventario")

	if not inventario or inventario.items.is_empty():
		return

	item_atual -= 1

	if item_atual < 0:
		item_atual = inventario.items.size() - 1

	atualizar_item()


func _on_right_arrow_pressed():

	var inventario = get_tree().get_first_node_in_group("inventario")

	if not inventario or inventario.items.is_empty():
		return

	item_atual += 1

	if item_atual >= inventario.items.size():
		item_atual = 0

	atualizar_item()
