extends Panel

@onready var texto = $Label

var falas = []
var fala_atual = 0


func _ready():
	add_to_group("caixa_texto")
	visible = false


func mostrar_falas(novas_falas):

	falas = novas_falas
	fala_atual = 0

	visible = true

	texto.text = falas[fala_atual]


func _input(event):

	if not visible:
		return

	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:

			fala_atual += 1

			if fala_atual >= falas.size():
				visible = false
			else:
				texto.text = falas[fala_atual]
