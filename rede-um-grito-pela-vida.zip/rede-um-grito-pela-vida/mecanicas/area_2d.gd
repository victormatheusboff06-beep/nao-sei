extends Area2D

func _on_input_event(viewport, event, shape_idx):
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			print("Cliquei na chave!")

			var inventario = get_tree().get_first_node_in_group("inventario")

			if inventario:
				inventario.add_item("Chave")

			queue_free()
