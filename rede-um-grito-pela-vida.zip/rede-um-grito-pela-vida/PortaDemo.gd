extends Area2D

@export_file("*.tscn") var trocaCena: String
var trocaSala = false
var aberta := false

func _ready():
	input_pickable = true
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)

func _on_mouse_entered():
	$PortaF.visible = false
	$PortaA.visible = true
	trocaSala = true

func _on_mouse_exited():
	$PortaF.visible = true
	$PortaA.visible = false
	trocaSala = false

func _process(delta):
	if Input.is_action_just_pressed("clickE") and trocaSala == true:
		var inventario = get_tree().get_first_node_in_group("inventario")

		if inventario and "Chave" in inventario.items:
			abrir()
		else:
			var caixa = get_tree().get_first_node_in_group("caixa_texto")
			if caixa:
				caixa.mostrar_falas([
					"A porta está trancada.",
					"Talvez eu precise de uma chave."
				])

func abrir():
	if aberta:
		return

	aberta = true
	print("Porta aberta!")

	$PortaF.visible = false
	$PortaA.visible = true
	$Porta.set_deferred("disabled", true)

	var inventario = get_tree().get_first_node_in_group("inventario")
	if inventario:
		inventario.remove_item("Chave")

	if trocaCena:
		get_tree().change_scene_to_file(trocaCena)
