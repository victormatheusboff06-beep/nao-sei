/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ativ8;

import java.util.Scanner;
public class Ativ8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         System.out.println("limite de valor de 0 a 10");
       Scanner teclado = new Scanner(System.in);
        System.out.println("de valor ao A");
        int a = teclado.nextInt();
        System.out.println("de valor ao b");
        int b = teclado.nextInt();
        System.out.println("de valor ao b");
        int c = teclado.nextInt();
        System.out.println("fazendo conta");
        int d = 3;
        int f = a + b + c;
        int g = f / d;
       
            if (g >= 7) {
                System.out.println("aprovado");
         } else {
            System.out.println("nao aprovado");
        }
         
    }
    
}
