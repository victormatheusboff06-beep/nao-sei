package vetor4;

import java.util.Scanner;

public class Vetor4 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int tamanho = 5, tamanho2 = 10, contador = 0, contador2 = 0;
        String[] animais = new String[tamanho];
        String[] frutas = new String[tamanho];
        String[] gororoba = new String[tamanho2];

        for (int i = 0; i < tamanho; i++) {
            System.out.println("informe uma fruta");
            frutas[i] = teclado.nextLine();
        }

        for (int i = 0; i < tamanho; i++) {
            System.out.println("informe um animal");
            animais[i] = teclado.nextLine();
        }

        for (int j = 0; j < tamanho2; j++) {
            if (j % 2 != 0) {
                gororoba[j] = frutas[contador];
                contador++;
            } else if (j % 2 == 0) {
                gororoba[j] = animais[contador2];
                contador2++;
            }
        }

        for (int j = 0; j < tamanho2; j+=2) {
            System.out.println(gororoba[j]+" "+gororoba[j+1]);
        }
    }
}
