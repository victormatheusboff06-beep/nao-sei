
package vetor5;

import java.util.Scanner;

public class Vetor5 {

    public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    int tamanho = 100, tamanho2 = 5;
    int[] numeros1 = new int[tamanho];
    int[] numeros2 = new int[tamanho2];
    
        for (int i = 0; i < tamanho; i++) {
            System.out.println("digite um numero");
            numeros1[i] = teclado.nextInt();
        }
        
        for (int i = 0; i < tamanho2; i++) {
            System.out.println("digite um numero");
            numeros1[i] = teclado.nextInt();
        }
        
        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho2; j++) {
                if (numeros1[i]==numeros2[j]) {
                    System.out.println(numeros2[j]);
                }
            }   
        }
    }  
}

