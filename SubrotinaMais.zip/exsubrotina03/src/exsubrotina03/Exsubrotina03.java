
package exsubrotina03;


public class Exsubrotina03 {

    static int tempo(int time) {
        int resp = 0;
        int H;
        int M;
        int S;
        H = time / 3600;
        int a = time % 3600;
        M = a / 60;
        S = time % 60;
        int k = H * 60;
        if (24 < H) {
            System.out.println("Atingiu o limite de horas");
            System.exit(0);
        }
        System.out.println(M + k);
        return resp;
    }
    public static void main(String[] args) {
        tempo(90000);
        
    }
    
}
