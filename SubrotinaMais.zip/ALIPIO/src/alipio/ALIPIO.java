
package alipio;


public class ALIPIO {
    
    static boolean primo(int a) {
        
        boolean q;
        if (a % 2 == 0) {
            q = true;
            System.out.println(q);
            System.out.println("é primo");
        } else {
            q = false;
            System.out.println(q);
            System.out.println("não é primoé");
        }
        return q;
    }
    
    public static void main(String[] args) {
        
        primo(4);
        
    }
    
}
