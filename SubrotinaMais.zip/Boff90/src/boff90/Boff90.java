package boff90;


public class Boff90 {

    static void god(int []a, int b, int c) {
        System.out.println("do menor pro maior");
        System.out.println(a[0]);
        for (int i = 0; i < a.length; i++) {
            if (a[i] > b) {
                System.out.println(a[i]);
            } else if (a[i] < c) {
                System.out.println(a[i]);
            }
        }
    }
    
            
    public static void main(String[] args) {
        
        int []numero = {1,2,3,4,5};
        int maior = numero[0];
        int menor = numero[0];
        god(numero, maior, menor);
        
    }
    
}
