/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package media;

import java.util.Scanner;

public class Media {

    static void saving(int a, int b, int c, String d) {
        int total = 0;
        if ("a".equals(d)) {
            total = (a + b + c) / 3;
        } else if ("p".equals(d)) {
            total = ((a * 5) + (b * 3) + (c * 2)) / (5 + 3 + 2);
        }
        System.out.println(total);
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int a1 = 0, b1 = 0, c1 = 0;
        String oi;
        System.out.println("digite a primeira nota");
        a1 = sc.nextInt();
        System.out.println("digite a segunda nota");
        b1 = sc.nextInt();
        System.out.println("digite a terceira nota");
        c1 = sc.nextInt();
        sc.nextLine();
        System.out.println("digite 'a' para media aritmedica ou 'p' para media poderada: ");
        oi = sc.nextLine();
        
        saving(a1, b1, c1, oi);
        
        
        
    }
    
}
