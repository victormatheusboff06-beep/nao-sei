/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package triangulo;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Triangulo {

    static String trian(int a, int b, int c) {
        String resp = null;
        if (a == 3 && b == 3 && c == 3) {
            resp = "seu triangulo é equilátero";
        } else if(a == 2 && b == 3 && c == 4) {
            resp = "seu triangulo é escaleno";
        } else if(a == 2 && b == 4 && c == 3) {
            resp = "seu triangulo é escaleno";
        } else if(a == 3 && b == 2 && c == 4) {
            resp = "seu triangulo é escaleno";
        } else if(a == 3 && b == 4 && c == 2) {
            resp = "seu triangulo é escaleno";
        } else if(a == 4 && b == 2 && c == 3) {
            resp = "seu triangulo é escaleno";
        } else if(a == 4 && b == 3 && c == 2) {
            resp = "seu triangulo é escaleno";
        } else if(a == 5 && b == 6 && c == 6) {
            resp = "seu triangulo é Isósceles";
        } else if(a == 6 && b == 5 && c == 6) {
            resp = "seu triangulo é Isósceles";
        } else if(a == 6 && b == 6 && c == 5) {
            resp = "seu triangulo é Isósceles";
        } else {
            resp = "Isto nao é um triangulo";
        }
        
            return resp;
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        String tri;
        int a, b, c;
        System.out.println("so pode digitar um nuero de lados de cada");
        System.out.println("primeiro lado");
        a = sc.nextInt();
        System.out.println("segundo lado");
        b = sc.nextInt();
        System.out.println("terceiro lado");
        c = sc.nextInt();
        tri = trian(a, b, c);
        System.out.println(tri);
    }
    
}
