/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package boff.pkg3mc;

import java.util.Scanner;
public class Boff3MC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int count = 0;
        String A;
        System.out.println("Informe as frases:");
        A = sc.nextLine();
        String resp[] = A.split(" ");
        for (int i = 0; i < resp.length; i++) {
             count++;
        }
        System.out.println("o numero de frases foi: " + count);
    }
    
}
