package boff6mc;

import java.util.Scanner;

public class Boff6MC {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int count = 0;
        String A;
        System.out.println("Informe seu nome:");
        A = sc.nextLine();
        String resp[] = A.split(" ");
        for (int i = 1; i < resp.length; i++) {
             count++;
             if (count == 1) {
                 System.out.print(resp[0]);
                 System.out.print(", ");
                 System.out.print(resp[1]);
             } else {
                 System.out.print(" " + resp[i]);
             }
                 
                 
            
        }       
    }      
}
