package boff5mc;

import java.util.Scanner;

public class Boff5MC {

    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        String dd = "1";
        String mm = "1";
        int aa = 1;
        
        System.out.println("Informe o dia");
        
        dd = sc.nextLine();
        
        System.out.println("Informe o mês");
        
        mm = sc.nextLine();
        
        System.out.println("Informe o ano");
        
        aa = sc.nextInt();
        
        System.out.println("a data é: " + dd + "/" + mm + "/" + aa);
        if (9999 < aa) {
            System.out.println("Ta achando que ta no futuro??");
            System.exit(0);
        }
        
        aa++;
        
        System.out.println("a proxima data vai ser: " + dd + "/" + mm + "/" + aa);
        System.out.println("vai levar: 365 dias. até a proxima data!é");
            
    }
}
