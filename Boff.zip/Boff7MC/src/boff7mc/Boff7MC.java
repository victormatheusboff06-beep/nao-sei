/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package boff7mc;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Boff7MC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int count = 0;
        String A;
        String S;
        System.out.println("Informe seu nome:");
        A = sc.nextLine();
        String resp[] = A.split(" ");
        for (int i = 1; i < resp.length; i++) {
             count++;
             if (count == 1) {
                 System.out.print(resp[0]);
             } else {
                 S = resp.charAt(0);
                 System.out.print(" " + resp[i]);
             }
        
    }
    
}
