package javaapplication17;

import java.util.Scanner;

public class JavaApplication17 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int count = 0;
        String A;
        System.out.println("Informe seu nome:");
        A = sc.nextLine();
        String resp[] = A.split(" ");
        for (int i = 0; i < resp.length; i++) {
             count++;
             if (i == 1) {
                 System.out.println("Ola senhor " + resp[0]);
                 System.exit(0);
             } else {
                 System.out.println("Erro critico!");
             }
        }
        System.out.println();
        
    }
    
}
