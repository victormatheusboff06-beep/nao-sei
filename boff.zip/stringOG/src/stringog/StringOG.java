/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stringog;

import java.util.Scanner;

public class StringOG {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        String str = "ka";
        String frase;
        System.out.println("Digite Algo");
        str = sc.nextLine();

        int Resp1 = 0;
        int Resp2 = 0;
        int Resp3 = 0;
        int Resp4 = 0;
        int Resp5 = 0;
        
        str = str.toUpperCase();
        
        
        for (int i = 0; i < str.length(); i++) {
            Resp1 = str.indexOf('a') + 1;
        Resp2 = str.indexOf('e') + 1;
        Resp3 = str.indexOf('i') + 1;
        Resp4 = str.indexOf('o') + 1;
        Resp5 = str.indexOf('u') + 1;
        }
        for (int i = 0; i < str.length(); i++) {
            if (frase.charAt(i) || frase.charAt(A) || frase.charAt(E) || frase.charAt(I) || frase.charAt(O) || frase.charAt(U) ) {
                
            }
        }
        System.out.println("Oque o usuario escreveu tem vogais:");
        System.out.println("/n===============================");
        System.out.println("/n|  A  |  E  |  O  |  I  |  U  |");
        System.out.println("/n|  " + Resp1 +"  |  " + Resp2 +"  |  " + Resp3 +"  |  " + Resp4 +"  |  " + Resp5 +"  |  ");
        System.out.println("/n===============================");
    }
    
}
