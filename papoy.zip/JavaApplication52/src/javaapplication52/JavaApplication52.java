                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication52;


import java.util.Scanner;
public class JavaApplication52 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Scanner bilk = new Scanner(System.in);
        
        int a = 0, b = 1,c;
        int n;
        
        System.out.println("diga a quantidade de termos: ");
        
        n = bilk.nextInt();
        
        for (int i = 1; i <= n; i++) {
            System.out.println(a + "");
            
            c = a + b;
            a = b;
            b = c;
        }
    }
    
}
