/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication50;

import java.util.Scanner;
public class JavaApplication50 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner bilk = new Scanner(System.in);
        
        int eleitores;
        int aaa = 0, bbb = 0, ccc = 0,branco = 0;
        
        System.out.println("quantidade de eleitores: ");
        eleitores = bilk.nextInt();
        
        for (int i = 1; i <= eleitores; i++) {
            System.out.println("\nEleitor " + i);
            System.out.println("1 - aaa");
            System.out.println("2 - bbb");
            System.out.println("3 - ccc");
            System.out.println("4 - branco");
            System.out.println("digite seu voto");
            
            int voto = bilk.nextInt();
            
            switch (voto) {
                case 1:
                    aaa++;
                    break;
                case 2:
                    bbb++;
                    break;
                case 3:
                    ccc++;
                    break;
                case 4:
                    branco++;
                    break;
                default:
                    System.out.println("voto invalido");
            }
            
        }
        
        System.out.println("\nResultado da Eleição: ");
        System.out.println("aaa :" + aaa);
        System.out.println("bbb :" + bbb);
        System.out.println("ccc :" + ccc);
        System.out.println("branco :" + branco);
        
        if (aaa > bbb && aaa > ccc) {
            System.out.println("Vencedor aaa");
        } else if (bbb > aaa && bbb > ccc) {
            System.out.println("Vencedor bbb");
        } else if (ccc > aaa && ccc > bbb) {
            System.out.println("Vencedor ccc");
        } else {
            System.out.println("empate entre candidatos");
        }
        
    }
    
}
