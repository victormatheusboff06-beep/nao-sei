/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication49;

import java.util.Scanner;
public class JavaApplication49 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner roger = new Scanner(System.in);
        System.out.println("Digite a quantidade de termos:");
        
        int n = roger.nextInt();
        
        int valor = 2;
        int i;
        
        for (i = 1; i <= n; i++) {
            System.out.println(valor + "");
            valor = valor * 2;
        }
        
        
        
    }
    
}
