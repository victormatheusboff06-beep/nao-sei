/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio1;

/**
 *
 * @author alunos
 */
public class EXERCICIO1 {

    
    public static void main(String[] args) {
        int multiplicando = 0, multiplicador = 0;
        
        
        while (multiplicador <= 10 && multiplicando <= 10) {
            System.out.println(multiplicando + " X " + multiplicador + " = " + multiplicador * multiplicando);
            multiplicador++;
            if (multiplicador > 10) {
                multiplicador = 0;
                multiplicando++;
            }
        }
        
            
        
    }
    
}
