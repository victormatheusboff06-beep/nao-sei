/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio4;

import java.util.Scanner;
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int numero;
        long fatorial = 1;
        
        System.out.print("digite um numero");
        numero = sc.nextInt();
        
        for ( int i = 1; i <= numero; i++ ) {
            fatorial *= i;
        }
        
        System.out.println(numero + "! = " + fatorial);
    }
    
}
