/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication54;

import java.util.Scanner;
public class JavaApplication54 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Scanner miguel = new Scanner(System.in);
        
        int n;
        double e = 1;
        
        System.out.println("digite um numero");
        n = miguel.nextInt();
        
        for (int i = 1; i <= n; i++) {
            int fatorial = 1;
            
            for (int j = 1; j <= i; j++) {
                fatorial *= j;
            }
            
            e += (10.0*i)/fatorial;
        }
        
        System.out.println("Valor de E = " + e);
        
    }
    
}
