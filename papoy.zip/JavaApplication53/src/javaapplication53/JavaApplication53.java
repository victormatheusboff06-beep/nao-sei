/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication53;

import java.util.Scanner;
public class JavaApplication53 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner tarcia = new Scanner(System.in);
        
        int numero;
        int divisores = 0;
        
        System.out.println("digite um numero");
        numero = tarcia.nextInt();
        
        for (int i = 1; i <= numero; i++) {
            if (numero % i == 0) {
                divisores++;
            }
        }
        
        if (divisores == 2) {
            System.out.println("numero primo");
        } else {
            System.out.println("numero nao primo");
        }
        
    }
    
}
